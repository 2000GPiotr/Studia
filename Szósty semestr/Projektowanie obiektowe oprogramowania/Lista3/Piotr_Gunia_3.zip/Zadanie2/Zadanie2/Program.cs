﻿using System;

namespace Zadanie2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            ReportPrinter printer = new ReportPrinter();
            printer.PrintReport();
        }
    }
}
